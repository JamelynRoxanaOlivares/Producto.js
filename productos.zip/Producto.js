class Producto {
    constructor(nombre, precio, cantidad) {
      this.nombre = nombre;
      this.precio = precio;
      this.cantidad = cantidad;
    }
  
    calcularValorTotal() {
      return this.precio * this.cantidad;
    }
  }
  
  module.exports = Producto;
  