const diccionario = require('./diccionario');
const eliminados = diccionario.eliminados;

class Inventario {
  constructor() {
    this.productos = [];
  }

  registrarProducto(producto) {
    this.productos.push(producto);
    console.log(`El producto "${producto.nombre}" se a registradoo exitosamente.`);
  }

  actualizarCantidad(nombreProducto, nuevaCantidad) {
    const producto = this.productos.find(producto => producto.nombre === nombreProducto);
    if (producto) {
      const cantidadAnterior = producto.cantidad;
      producto.cantidad = nuevaCantidad;
      const cantidadEliminada = cantidadAnterior - nuevaCantidad;
      console.log(`Se actualizaron ${cantidadEliminada} unidades del producto "${nombreProducto}".`);
    }
  }

  visualizarProductos() {
    console.log('Productos en el inventario:');
    this.productos.forEach(producto => {
      console.log(`Nombre: ${producto.nombre}, Precio: ${producto.precio}, Cantidad: ${producto.cantidad}`);
    });
  }

  eliminarProducto(nombreProducto) {
    const indiceProducto = this.productos.findIndex(producto => producto.nombre === nombreProducto);
    if (indiceProducto !== -1) {
      const producto = this.productos[indiceProducto];
      const cantidadEliminada = eliminados[Math.floor(Math.random() * eliminados.length)];
      const cantidadAnterior = producto.cantidad;
      if (cantidadAnterior <= cantidadEliminada) {
        console.log(`Se eliminaron todas las unidades del producto "${nombreProducto}".`);
        this.productos.splice(indiceProducto, 1);
      } else {
        producto.cantidad -= cantidadEliminada;
        console.log(`Se eliminaron ${cantidadEliminada} unidades del producto "${nombreProducto}".`);
      }
    } else {
      console.log(`El producto "${nombreProducto}" no está en el inventario.`);
    }
  }
}

module.exports = Inventario;
