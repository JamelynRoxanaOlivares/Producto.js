const diccionario = require('./diccionario');
const Venta = require('./Venta');

const Producto = require('./Producto');
const Inventario = require('./Inventario');

function generarCantidadAleatoria() {
  return Math.floor(Math.random() * 20) + 1;
}

const inventario = new Inventario();

diccionario.nombresProductos.forEach((nombre, index) => {
  const precio = diccionario.preciosProductos[index];
  const cantidad = generarCantidadAleatoria();
  const producto = new Producto(nombre, precio, cantidad);
  inventario.registrarProducto(producto);
});

inventario.visualizarProductos();

const nombreProductoAEliminar = diccionario.nombresProductos[Math.floor(Math.random() * diccionario.nombresProductos.length)];
const productoEliminado = inventario.eliminarProducto(nombreProductoAEliminar);
if (productoEliminado) {
  console.log(`Se eliminó el producto: ${productoEliminado.nombre}`);

}

console.log('Inventario después de eliminar un producto:');
inventario.visualizarProductos();

const venta = new Venta(inventario);


venta.venderPrendaAleatoria();

console.log('Inventario después de la venta:');
inventario.visualizarProductos();
