module.exports = {
    nombresProductos: ["camiseta", "pantalones", "chaqueta", "bufanda", "calcetines", "zapatos", "gorra", "abrigo", "falda", "sombrero",
    "guantes", "sudadera", "blusa", "vestido", "bufanda", "chaleco", "botas", "corbata", "calcetines", "chaqueta de cuero",
    "jeans", "camisa", "chaqueta vaquera", "chaqueta de punto", "zapatos de tacón", "pijama", "traje", "ropa interior",
    "sudadera con capucha", "abrigo de plumas", "bikini", "sandalias", "mocasines", "top", "chaqueta de esquí", "pantalones cortos",
    "falda midi", "chándal", "traje de baño", "chaqueta deportiva", "parka", "chaqueta de aviador", "pajarita", "esmoquin",
    "vestido de cóctel", "pantalones de vestir", "leggings", "jersey de cuello alto"
],
    preciosProductos: [53, 78, 76, 94, 71, 75, 62, 96, 84, 88, 66, 81, 97, 92, 56, 57, 79, 89, 72, 91, 83, 69, 99, 73, 74, 87, 93, 86, 70, 
        95, 80, 55, 82, 90, 98, 67, 85, 77, 64, 61, 68, 59, 63, 52, 65, 54, 58, 51, 60, 100, 31, 49, 41, 35, 38, 48, 33, 42, 47, 45, 32, 34,
         39, 36, 46, 37, 44, 40, 43, 50, 86, 34, 41, 63, 97, 89, 56, 92, 51, 91, 71, 86, 48, 67, 94, 74.],
    cantidadesProductos: [5, 10, 15, 20, 25],
    eliminados: [1, 1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,3],
    cantidadesVendidas: [1, 2, 3, 4, 1]


    


  };
