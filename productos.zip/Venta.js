const inventario = require('./Inventario');
const diccionario = require('./diccionario');
const eliminados = diccionario.eliminados;

class Venta {
  constructor(inventario) {
    this.inventario = inventario;
    this.listaEspera = [];
  }

  venderPrendaAleatoria() {
    const nombresProductos = diccionario.nombresProductos;
    const cantidadesProductos = diccionario.cantidadesProductos;
    const eliminados = diccionario.eliminados;
    const cantidadesVendidas = diccionario.cantidadesVendidas;

    const indiceProductoAleatorio = Math.floor(Math.random() * nombresProductos.length);
    const nombreProducto = nombresProductos[indiceProductoAleatorio];
    const cantidadProducto = cantidadesProductos[Math.floor(Math.random() * cantidadesProductos.length)];
    const cantidadVendida = cantidadesVendidas[Math.floor(Math.random() * cantidadesVendidas.length)];
    const cantidadEliminada = eliminados[Math.floor(Math.random() * eliminados.length)];

    const productoEnInventario = this.inventario.productos.find(producto => producto.nombre === nombreProducto);

    if (productoEnInventario) {
      if (cantidadVendida <= productoEnInventario.cantidad) {
        productoEnInventario.cantidad -= cantidadVendida;
        console.log(`Venta realizada: Se vendieron ${cantidadVendida} unidades del producto "${nombreProducto}".`);
      } else {

        console.log(`No hay suficientes unidades del producto "${nombreProducto}" en el inventario.`);
      }
    } else {
      console.log(`El producto "${nombreProducto}" no está en el inventario.`);
    }
  }
}

module.exports = Venta;
